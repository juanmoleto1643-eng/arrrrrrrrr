# Publicar Aurum Motors en GitHub y Vercel

1. Descomprime este ZIP en tu computadora.
2. En GitHub, crea un repositorio nuevo.
3. Selecciona Add file → Upload files y sube los archivos y carpetas descomprimidos. No subas el ZIP como único archivo.
4. Coloca package.json, vite.config.ts, src y public en la raíz del repositorio, sin una carpeta adicional alrededor.
5. Guarda con Commit changes.
6. En Vercel, selecciona Add New → Project e importa ese repositorio.
7. Usa npm run build como Build Command, Node.js 22 y deja Output Directory sin configurar. Si Vercel solicita Install Command, usa npm install.
8. Pulsa Deploy.

Incluye la página completa, las imágenes y los controles originales. No requiere una base de datos ni claves privadas.

Antes de publicar para clientes, sustituye el nombre y los datos de contacto de ejemplo en src/lib/site-data.ts. Los vehículos y testimonios también son de muestra. El WhatsApp actual usa un número de ejemplo.

Este archivo es una copia del proyecto: subirlo manualmente no activa la sincronización con Lovable. Para sincronizar futuros cambios, conecta GitHub desde los ajustes de Git de Lovable; esa conexión crea un repositorio nuevo.

La publicación en tu cuenta de Vercel no ha sido verificada desde aquí.
