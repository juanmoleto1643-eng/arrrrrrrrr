import carSuv from "@/assets/car-suv.jpg";
import carSedan from "@/assets/car-sedan.jpg";
import carMinivan from "@/assets/car-minivan.jpg";
import carCrossover from "@/assets/car-crossover.jpg";

// Placeholder brand and contact details — replace with the real business info.
export const BRAND = {
  name: "Aurum Motors",
  tagline: "Bróker de subastas",
  city: "Nashville, TN",
  phoneDisplay: "+1 (615) 555-0142",
  whatsapp: "16155550142",
  email: "hola@aurummotors.example",
  address: "1200 Commerce Ave, Nashville, TN",
  hours: "Oficina: lunes a viernes, 9:00 AM – 5:00 PM ET · Asesores disponibles en horario extendido",
};

export const waLink = (text: string) =>
  `https://wa.me/${BRAND.whatsapp}?text=${encodeURIComponent(text)}`;

export const NAV = [
  { href: "#inicio", label: "Inicio" },
  { href: "#nosotros", label: "Quiénes somos" },
  { href: "#servicios", label: "Servicios" },
  { href: "#proceso", label: "Cómo funciona" },
  { href: "#carros", label: "Carros" },
  { href: "#contacto", label: "Contacto" },
];

export const PLATFORMS = ["COPART", "IAAI", "MANHEIM", "ADESA", "ACV AUCTIONS", "AMERICA'S AUTO AUCTION"];

export type Vehicle = {
  id: string;
  title: string;
  image: string;
  year: number;
  miles: number;
  price: number;
  tag: string;
  /** hours remaining in the listing window, used to seed the countdown */
  hoursLeft: number;
};

export const VEHICLES: Vehicle[] = [
  { id: "1", title: "SUV Todoterreno 2023 · Gasolina · Gris", image: carSuv, year: 2023, miles: 48210, price: 16900, tag: "Nuevo ingreso", hoursLeft: 40 },
  { id: "2", title: "Sedán Ejecutivo 2020 · Gasolina · Blanco", image: carSedan, year: 2020, miles: 74980, price: 10750, tag: "Entrega rápida", hoursLeft: 3 },
  { id: "3", title: "Crossover Compacto 2019 · Gasolina · Rojo", image: carCrossover, year: 2019, miles: 70410, price: 9200, tag: "Nuevo ingreso", hoursLeft: 28 },
  { id: "4", title: "Minivan Familiar 2017 · Gasolina · Negro", image: carMinivan, year: 2017, miles: 101870, price: 8490, tag: "Entrega rápida", hoursLeft: 1 },
];

export const TESTIMONIALS = [
  { name: "Daniela R.", place: "Miami, FL", stars: 5, text: "Me explicaron cada paso y siempre supe dónde estaba mi carro. Llegó tal como lo vi en las fotos." },
  { name: "Jorge P.", place: "Houston, TX", stars: 5, text: "Encontraron una camioneta dentro de mi presupuesto en menos de una semana. Muy profesionales." },
  { name: "Mariana S.", place: "Orlando, FL", stars: 4, text: "El transporte tardó un poco más de lo previsto, pero me avisaron a tiempo y todo salió perfecto." },
];
