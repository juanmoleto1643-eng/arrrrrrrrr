import { createFileRoute } from "@tanstack/react-router";
import { Hero } from "@/components/site/Hero";
import { LeadForm } from "@/components/site/LeadForm";
import { About } from "@/components/site/About";
import { Services } from "@/components/site/Services";
import { Process } from "@/components/site/Process";
import { Inventory } from "@/components/site/Inventory";
import { Testimonials } from "@/components/site/Testimonials";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Aurum Motors — Bróker de subastas de autos en EE.UU." },
      { name: "description", content: "Compramos tu próximo carro en las subastas de Estados Unidos o elige de nuestro inventario con entrega inmediata." },
      { property: "og:title", content: "Aurum Motors — Bróker de subastas de autos" },
      { property: "og:description", content: "Búsqueda, puja, documentos y transporte de tu vehículo desde las subastas de EE.UU." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <Hero />
      <LeadForm />
      <About />
      <Services />
      <Process />
      <Inventory />
      <Testimonials />
    </>
  );
}
