import { useEffect, useState } from "react";
import { MapPin, MessageCircle, Timer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BRAND, VEHICLES, waLink, type Vehicle } from "@/lib/site-data";

const fmt = (n: number) => n.toLocaleString("en-US");

function Countdown({ hours }: { hours: number }) {
  const [left, setLeft] = useState<number | null>(null);
  useEffect(() => {
    const end = Date.now() + hours * 3600_000;
    const tick = () => setLeft(Math.max(0, end - Date.now()));
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [hours]);
  if (left === null) return <span className="tabular-nums">--:--:--</span>;
  const s = Math.floor(left / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return <span className="tabular-nums">{d > 0 ? `${d}d ` : ""}{pad(h)}h {pad(m)}m {pad(sec)}s</span>;
}

function VehicleCard({ v }: { v: Vehicle }) {
  const urgent = v.hoursLeft < 6;
  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-card transition-colors hover:border-primary/50">
      <div className="relative h-56 overflow-hidden">
        <img src={v.image} alt={v.title} loading="lazy" width={1200} height={800} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
        <span className="absolute left-3 top-3 rounded-full bg-success px-3 py-1 text-xs font-semibold text-success-foreground">Disponible</span>
        <span className="absolute right-3 top-3 rounded-full bg-overlay/80 px-3 py-1 text-xs font-medium text-primary backdrop-blur">{v.tag}</span>
      </div>
      <div className={urgent ? "flex items-center justify-between bg-destructive/15 px-5 py-2 text-xs font-semibold text-destructive" : "flex items-center justify-between bg-primary/10 px-5 py-2 text-xs font-semibold text-primary"}>
        <span className="flex items-center gap-1.5"><Timer className="size-3.5" />{urgent ? "¡Últimas horas!" : "En vivo"}</span>
        <Countdown hours={v.hoursLeft} />
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-semibold leading-snug">{v.title}</h3>
        <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="size-3" />{BRAND.city} · Título limpio</p>
        <div className="mt-4 grid grid-cols-2 gap-3 rounded-lg bg-muted/60 p-3 text-xs">
          <div><p className="text-muted-foreground">Año</p><p className="font-semibold">{v.year}</p></div>
          <div><p className="text-muted-foreground">Millaje</p><p className="font-semibold">{fmt(v.miles)}</p></div>
        </div>
        <div className="mt-4 flex items-end justify-between">
          <div>
            <p className="text-xs text-muted-foreground">Precio</p>
            <p className="font-display text-4xl text-gradient-gold">${fmt(v.price)}</p>
          </div>
        </div>
        <div className="mt-5 grid gap-2">
          <Button variant="whatsapp" asChild>
            <a href={waLink(`Hola, me interesa el vehículo: ${v.title}`)} target="_blank" rel="noreferrer"><MessageCircle /> Chatear con un asesor</a>
          </Button>
        </div>
      </div>
    </article>
  );
}

export function Inventory() {
  return (
    <section id="carros" className="mx-auto max-w-7xl px-4 py-24 sm:px-6">
      <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
        <div className="max-w-2xl">
          <p className="eyebrow">Inventario directo</p>
          <h2 className="mt-4 font-display text-5xl leading-none md:text-6xl">
            Carros listos para <span className="text-gradient-gold">entrega inmediata</span>
          </h2>
          <p className="mt-5 text-muted-foreground">Unidades seleccionadas con título limpio, precio directo y sin intermediarios.</p>
        </div>
        <Button variant="goldOutline" size="lg" asChild>
          <a href={waLink("Hola, quiero ver el catálogo completo.")} target="_blank" rel="noreferrer">Ver catálogo completo</a>
        </Button>
      </div>
      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {VEHICLES.map((v) => <VehicleCard key={v.id} v={v} />)}
      </div>
    </section>
  );
}
