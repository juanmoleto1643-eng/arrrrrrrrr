import { BRAND } from "@/lib/site-data";

export function Logo() {
  return (
    <a href="#inicio" className="flex items-center gap-3" aria-label={BRAND.name}>
      <span className="grid size-11 place-items-center rounded-full bg-gradient-gold font-display text-2xl text-primary-foreground shadow-gold">
        A
      </span>
      <span className="leading-none">
        <span className="block font-display text-2xl tracking-[0.12em] text-foreground">{BRAND.name}</span>
        <span className="block text-[0.65rem] uppercase tracking-[0.35em] text-primary">{BRAND.tagline}</span>
      </span>
    </a>
  );
}
