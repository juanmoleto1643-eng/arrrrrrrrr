import { MessageCircle } from "lucide-react";
import delivery from "@/assets/delivery.jpg";
import { Button } from "@/components/ui/button";
import { waLink } from "@/lib/site-data";

const STEPS = [
  { title: "Nos escribes", text: "Cuéntanos por WhatsApp o correo qué buscas, tu presupuesto y dónde estás. Te asignamos un asesor sin compromiso." },
  { title: "Buscamos y filtramos", text: "Revisamos historial, condición y precio de cada opción. Solo te presentamos vehículos que nosotros mismos compraríamos." },
  { title: "Acuerdo y puja", text: "Firmamos un acuerdo digital en minutos y pujamos por ti. Los pagos van siempre a la cuenta empresarial de la compañía." },
  { title: "Recibes tu carro", text: "Cuando el vehículo llega a destino pagas la tarifa de servicio acordada. Sin cargos ocultos ni sorpresas." },
];

export function Process() {
  return (
    <section id="proceso" className="border-y border-border bg-surface">
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 py-24 sm:px-6 lg:grid-cols-2">
        <div className="relative">
          <img src={delivery} alt="Entrega de llaves a un cliente" loading="lazy" width={1600} height={1024} className="aspect-[4/5] w-full rounded-3xl object-cover shadow-card" />
          <div className="absolute -bottom-6 -right-4 rounded-2xl border border-primary/40 bg-card px-6 py-5 shadow-gold sm:right-6">
            <p className="font-display text-5xl text-gradient-gold">4 pasos</p>
            <p className="text-sm text-muted-foreground">De tu mensaje a tus llaves</p>
          </div>
        </div>
        <div>
          <p className="eyebrow">Cómo funciona</p>
          <h2 className="mt-4 font-display text-5xl leading-none md:text-6xl">
            Un proceso simple, <span className="text-gradient-gold">claro y seguro</span>
          </h2>
          <ol className="mt-10 space-y-8">
            {STEPS.map((s, i) => (
              <li key={s.title} className="flex gap-5">
                <span className="grid size-12 shrink-0 place-items-center rounded-full border border-primary/60 font-display text-xl text-primary">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div>
                  <h3 className="font-display text-2xl tracking-wide">{s.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{s.text}</p>
                </div>
              </li>
            ))}
          </ol>
          <Button variant="gold" size="xl" className="mt-10" asChild>
            <a href={waLink("Hola, quiero iniciar mi proceso de compra.")} target="_blank" rel="noreferrer">
              <MessageCircle /> Iniciar mi proceso
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
