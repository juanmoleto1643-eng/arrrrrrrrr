import { MessageCircle } from "lucide-react";
import { waLink } from "@/lib/site-data";

export function WhatsAppFab() {
  return (
    <a
      href={waLink("Hola, vi su página y quiero información.")}
      target="_blank"
      rel="noreferrer"
      aria-label="Escribir por WhatsApp"
      className="fixed bottom-6 right-6 z-50 grid size-14 place-items-center rounded-full bg-success text-success-foreground shadow-card transition-transform hover:scale-110"
    >
      <MessageCircle className="size-7" />
    </a>
  );
}
