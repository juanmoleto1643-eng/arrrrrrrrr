import { ArrowRight, Check, Gavel, Warehouse } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PLATFORMS } from "@/lib/site-data";

const CARDS = [
  {
    icon: Gavel,
    label: "Bróker de subastas",
    title: "Compra en subasta",
    text: "¿Ya sabes qué carro quieres? Lo buscamos en las grandes subastas, pujamos por ti y nos encargamos de todos los documentos. Cobramos una tarifa fija, sin importar el precio del vehículo.",
    points: ["Acceso a las principales subastas", "Compra a tu nombre", "Trámites y documentos incluidos", "Tarifa de servicio fija"],
    cta: { label: "Iniciar proceso", href: "#proceso" },
  },
  {
    icon: Warehouse,
    label: "Inventario propio",
    title: "Venta directa",
    text: "Vehículos seleccionados en nuestro lote, con precio directo y título limpio. Listos para revisar, comprar y llevarte de inmediato.",
    points: ["Lote propio en Nashville, TN", "Precio directo, sin intermediarios", "Título limpio verificado", "Disponibles hoy mismo"],
    cta: { label: "Ver carros disponibles", href: "#carros" },
  },
];

export function About() {
  return (
    <section id="nosotros" className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <div className="mx-auto max-w-3xl text-center">
        <p className="eyebrow">Quiénes somos</p>
        <h2 className="mt-4 font-display text-5xl leading-none md:text-6xl">
          El mercado automotriz de EE.UU. <span className="text-gradient-gold">a tu alcance</span>
        </h2>
        <p className="mt-6 text-lg text-muted-foreground">
          Unimos dos formas de comprar: conseguimos el vehículo que quieras en subasta, o eliges uno de nuestro inventario disponible.
        </p>
      </div>

      <div className="mt-14 grid gap-6 md:grid-cols-2">
        {CARDS.map((c) => (
          <article key={c.title} className="group relative overflow-hidden rounded-2xl border border-border bg-card p-8 shadow-card transition-colors hover:border-primary/50 sm:p-10">
            <div className="absolute -right-16 -top-16 size-48 rounded-full bg-primary/10 blur-3xl transition-opacity group-hover:opacity-100" />
            <div className="relative">
              <div className="flex items-center gap-4">
                <span className="grid size-12 place-items-center rounded-xl bg-gradient-gold text-primary-foreground"><c.icon className="size-6" /></span>
                <span className="eyebrow text-sm">{c.label}</span>
              </div>
              <h3 className="mt-6 font-display text-4xl tracking-wide">{c.title}</h3>
              <p className="mt-4 leading-relaxed text-muted-foreground">{c.text}</p>
              <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                {c.points.map((p) => (
                  <li key={p} className="flex items-start gap-2 text-sm text-foreground/90"><Check className="mt-0.5 size-4 shrink-0 text-primary" />{p}</li>
                ))}
              </ul>
              <Button variant="link" className="mt-6 px-0 text-base" asChild>
                <a href={c.cta.href}>{c.cta.label} <ArrowRight /></a>
              </Button>
            </div>
          </article>
        ))}
      </div>

      <div className="mt-20">
        <p className="eyebrow text-center text-sm">Plataformas con las que trabajamos</p>
        <div className="relative mt-8 overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_15%,black_85%,transparent)]">
          <div className="flex w-max animate-marquee gap-16">
            {[...PLATFORMS, ...PLATFORMS].map((p, i) => (
              <span key={i} className="font-display text-3xl tracking-[0.2em] text-foreground/40 transition-colors hover:text-primary">{p}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
