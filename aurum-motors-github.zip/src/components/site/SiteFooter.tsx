import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { BRAND, NAV, waLink } from "@/lib/site-data";
import { Logo } from "./Logo";
import { Button } from "@/components/ui/button";

export function SiteFooter() {
  const year = 2026;
  return (
    <footer id="contacto" className="relative border-t border-border bg-overlay">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-gold opacity-60" />
      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 md:grid-cols-2 lg:grid-cols-4">
        <div className="space-y-5">
          <Logo />
          <p className="text-sm leading-relaxed text-muted-foreground">
            Compramos por ti en las principales subastas de Estados Unidos y tenemos inventario propio listo para entrega.
          </p>
          <Button variant="whatsapp" asChild>
            <a href={waLink("Hola, quiero información sobre un vehículo.")} target="_blank" rel="noreferrer">
              Escríbenos por WhatsApp
            </a>
          </Button>
        </div>

        <div>
          <h3 className="eyebrow mb-5">Navegación</h3>
          <ul className="space-y-3 text-sm">
            {NAV.map((n) => (
              <li key={n.href}>
                <a href={n.href} className="text-foreground/80 transition-colors hover:text-primary">{n.label}</a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="eyebrow mb-5">Contacto</h3>
          <ul className="space-y-4 text-sm text-foreground/80">
            <li className="flex gap-3"><Phone className="mt-0.5 size-4 shrink-0 text-primary" />{BRAND.phoneDisplay}</li>
            <li className="flex gap-3"><Mail className="mt-0.5 size-4 shrink-0 text-primary" />{BRAND.email}</li>
            <li className="flex gap-3"><MapPin className="mt-0.5 size-4 shrink-0 text-primary" />{BRAND.address}</li>
            <li className="flex gap-3"><Clock className="mt-0.5 size-4 shrink-0 text-primary" />Lun – Vie · 9:00 AM – 5:00 PM ET</li>
          </ul>
        </div>

        <div>
          <h3 className="eyebrow mb-5">Legal</h3>
          <ul className="space-y-3 text-sm">
            {["Términos y condiciones", "Política de privacidad", "Política de cookies", "Aviso de pagos seguros"].map((l) => (
              <li key={l}><a href="#contacto" className="text-foreground/80 transition-colors hover:text-primary">{l}</a></li>
            ))}
          </ul>
          <p className="mt-6 rounded-lg border border-primary/30 bg-accent/40 p-4 text-xs leading-relaxed text-accent-foreground">
            Solo recibimos pagos en cuentas empresariales a nombre de la compañía. Nunca en cuentas personales.
          </p>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-muted-foreground sm:flex-row sm:px-6">
          <p>© {year} {BRAND.name} LLC. Todos los derechos reservados.</p>
          <p>{BRAND.city} · Estados Unidos</p>
        </div>
      </div>
    </footer>
  );
}
