import { MessageCircle, Star } from "lucide-react";
import carrier from "@/assets/carrier.jpg";
import { Button } from "@/components/ui/button";
import { TESTIMONIALS, waLink } from "@/lib/site-data";

export function Testimonials() {
  return (
    <>
      <section className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl border border-primary/30">
          <img src={carrier} alt="" loading="lazy" width={1600} height={1024} className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-hero" />
          <div className="relative flex flex-col items-start gap-6 p-10 sm:p-16">
            <h2 className="max-w-xl font-display text-5xl leading-none md:text-6xl">¿Listo para comprar en subasta?</h2>
            <p className="max-w-md text-lg text-foreground/85">Cada semana hay miles de vehículos nuevos en las subastas. Te ayudamos a elegir el correcto.</p>
            <Button variant="gold" size="xl" asChild>
              <a href={waLink("Hola, quiero comprar en subasta.")} target="_blank" rel="noreferrer"><MessageCircle /> Hablar con un asesor</a>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-24 sm:px-6">
        <div className="text-center">
          <p className="eyebrow">Testimonios</p>
          <h2 className="mt-4 font-display text-5xl leading-none md:text-6xl">
            Lo que dicen <span className="text-gradient-gold">nuestros clientes</span>
          </h2>
        </div>
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <figure key={t.name} className="flex flex-col rounded-2xl border border-border bg-card p-8 shadow-card">
              <div className="flex text-primary">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={i < t.stars ? "size-4 fill-current" : "size-4 text-muted-foreground"} />
                ))}
              </div>
              <blockquote className="mt-5 flex-1 leading-relaxed text-foreground/85">“{t.text}”</blockquote>
              <figcaption className="mt-6 flex items-center gap-3 border-t border-border pt-5">
                <span className="grid size-10 place-items-center rounded-full bg-gradient-gold font-display text-lg text-primary-foreground">{t.name[0]}</span>
                <div>
                  <p className="font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.place}</p>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>
    </>
  );
}
