import { useEffect, useState } from "react";
import { MessageCircle } from "lucide-react";
import heroLot from "@/assets/hero-lot.jpg";
import auctionYard from "@/assets/auction-yard.jpg";
import carrier from "@/assets/carrier.jpg";
import { Button } from "@/components/ui/button";
import { BRAND, waLink } from "@/lib/site-data";
import { cn } from "@/lib/utils";

const SLIDES = [
  { image: heroLot, title: BRAND.city, text: BRAND.hours },
  { image: auctionYard, title: "Miles de subastas", text: "Accedemos cada semana a miles de vehículos en las principales subastas del país." },
  { image: carrier, title: "Hasta tu puerta", text: "Coordinamos el transporte y te mantenemos informado en cada kilómetro." },
];

export function Hero() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setActive((a) => (a + 1) % SLIDES.length), 6000);
    return () => clearInterval(t);
  }, []);

  const slide = SLIDES[active] ?? SLIDES[0]!;

  return (
    <section id="inicio" className="mx-auto max-w-7xl px-4 pt-6 sm:px-6">
      <div className="relative h-[560px] overflow-hidden rounded-3xl border border-border shadow-card md:h-[640px]">
        {SLIDES.map((s, i) => (
          <img
            key={i}
            src={s.image}
            alt=""
            width={1920}
            height={1088}
            className={cn(
              "absolute inset-0 h-full w-full object-cover transition-all duration-[1200ms]",
              i === active ? "scale-100 opacity-100" : "scale-105 opacity-0",
            )}
          />
        ))}
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="relative flex h-full flex-col justify-center px-6 sm:px-14 md:px-20">
          <div className="mb-6 flex items-center gap-4">
            <span className="h-px w-12 bg-primary" />
            <div>
              <p className="font-display text-sm tracking-[0.4em] text-primary">{BRAND.tagline}</p>
              <p className="font-display text-2xl tracking-[0.2em] text-foreground">{BRAND.name}</p>
            </div>
          </div>
          <h1 key={active} className="animate-in fade-in slide-in-from-bottom-4 max-w-2xl font-display text-6xl leading-[0.9] text-foreground duration-700 sm:text-7xl md:text-8xl">
            {slide.title}
          </h1>
          <p className="mt-6 max-w-lg text-base leading-relaxed text-foreground/85 md:text-lg">{slide.text}</p>
          <div className="mt-10 flex flex-wrap gap-4">
            <Button variant="goldOutline" size="xl" asChild>
              <a href="#servicios">Nuestros servicios</a>
            </Button>
            <Button variant="whatsapp" size="xl" asChild>
              <a href={waLink("Hola, vi su página y quiero información sobre un vehículo.")} target="_blank" rel="noreferrer">
                <MessageCircle /> Hablar por WhatsApp
              </a>
            </Button>
          </div>
        </div>
        <div className="absolute bottom-6 left-1/2 flex -translate-x-1/2 gap-2">
          {SLIDES.map((_, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              aria-label={`Ver imagen ${i + 1}`}
              className={cn("h-2 rounded-full transition-all", i === active ? "w-8 bg-primary" : "w-2 bg-foreground/40")}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
