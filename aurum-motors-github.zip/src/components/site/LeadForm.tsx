import { useState } from "react";
import { Check, ShieldCheck, Star, Zap } from "lucide-react";
import auctionYard from "@/assets/auction-yard.jpg";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { waLink } from "@/lib/site-data";
import { cn } from "@/lib/utils";

const STEPS = ["Tus datos", "Tu vehículo", "Presupuesto"] as const;
const TYPES = ["Sedán", "SUV", "Pickup", "Minivan", "Deportivo", "Otro"];
const BUDGETS = ["Menos de $8,000", "$8,000 – $15,000", "$15,000 – $25,000", "Más de $25,000"];

export function LeadForm() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({ name: "", phone: "", email: "", city: "", type: "", budget: "" });
  const set = (k: keyof typeof data, v: string) => setData((d) => ({ ...d, [k]: v }));

  const valid =
    step === 0 ? data.name && data.phone && data.email && data.city : step === 1 ? data.type : data.budget;

  const finish = () => {
    const msg = `Hola, soy ${data.name} de ${data.city}. Busco un ${data.type} con presupuesto ${data.budget}. Tel: ${data.phone} · ${data.email}`;
    window.open(waLink(msg), "_blank", "noopener");
  };

  return (
    <section className="mx-auto max-w-7xl px-4 py-24 sm:px-6">
      <div className="relative overflow-hidden rounded-3xl border border-border">
        <img src={auctionYard} alt="" loading="lazy" width={1600} height={1024} className="absolute inset-0 h-full w-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="relative grid gap-12 p-6 sm:p-12 lg:grid-cols-2 lg:p-16">
          <div className="flex flex-col justify-center">
            <p className="eyebrow">Empieza aquí</p>
            <h2 className="mt-4 font-display text-5xl leading-none md:text-6xl">
              Tu próximo carro <span className="text-gradient-gold">empieza hoy</span>
            </h2>
            <p className="mt-6 max-w-md text-lg text-foreground/80">
              Cuéntanos qué buscas y nosotros hacemos la búsqueda, la puja y el papeleo en <strong className="text-foreground">Estados Unidos</strong>.
            </p>
            <ul className="mt-8 space-y-3">
              {["Compra segura y transparente", "Precios de subasta reales", "Acompañamiento de principio a fin"].map((t) => (
                <li key={t} className="flex items-center gap-3 text-foreground/90">
                  <span className="grid size-6 place-items-center rounded-full bg-primary/15 text-primary"><Check className="size-4" /></span>
                  {t}
                </li>
              ))}
            </ul>
            <div className="mt-10 flex items-center gap-3">
              <div className="flex text-primary">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-4 fill-current" />)}</div>
              <span className="text-sm text-muted-foreground">Cientos de clientes satisfechos</span>
            </div>
          </div>

          <div className="rounded-2xl border border-primary/30 bg-card/90 p-6 shadow-gold backdrop-blur sm:p-8">
            <div className="mb-6 flex items-center justify-between text-xs text-muted-foreground">
              <span>Paso {step + 1} de {STEPS.length}</span>
              <span className="text-primary">{STEPS[step]}</span>
            </div>
            <div className="mb-8 flex gap-2">
              {STEPS.map((_, i) => (
                <span key={i} className={cn("h-1 flex-1 rounded-full", i <= step ? "bg-primary" : "bg-muted")} />
              ))}
            </div>

            {step === 0 && (
              <div className="grid gap-4">
                <h3 className="font-display text-3xl tracking-wide">Cuéntanos sobre ti</h3>
                {([
                  ["name", "Nombre completo", "text"],
                  ["phone", "WhatsApp", "tel"],
                  ["email", "Correo electrónico", "email"],
                  ["city", "Ciudad y estado", "text"],
                ] as const).map(([k, label, type]) => (
                  <div key={k} className="grid gap-2">
                    <Label htmlFor={k}>{label}</Label>
                    <Input id={k} type={type} value={data[k]} onChange={(e) => set(k, e.target.value)} className="h-11 bg-background/60" />
                  </div>
                ))}
              </div>
            )}

            {step === 1 && (
              <div>
                <h3 className="mb-5 font-display text-3xl tracking-wide">¿Qué tipo de vehículo?</h3>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {TYPES.map((t) => (
                    <button key={t} onClick={() => set("type", t)} className={cn("rounded-lg border px-4 py-4 text-sm font-medium transition-colors", data.type === t ? "border-primary bg-primary/15 text-primary" : "border-border hover:border-primary/50")}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 2 && (
              <div>
                <h3 className="mb-5 font-display text-3xl tracking-wide">¿Cuál es tu presupuesto?</h3>
                <div className="grid gap-3">
                  {BUDGETS.map((b) => (
                    <button key={b} onClick={() => set("budget", b)} className={cn("rounded-lg border px-4 py-4 text-left text-sm font-medium transition-colors", data.budget === b ? "border-primary bg-primary/15 text-primary" : "border-border hover:border-primary/50")}>
                      {b}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {!valid && step === 0 && <p className="mt-4 text-xs text-muted-foreground">* Completa todos los campos para continuar</p>}

            <div className="mt-8 flex gap-3">
              {step > 0 && <Button variant="outline" size="lg" onClick={() => setStep((s) => s - 1)}>Atrás</Button>}
              <Button variant="gold" size="lg" className="flex-1" disabled={!valid} onClick={() => (step < STEPS.length - 1 ? setStep((s) => s + 1) : finish())}>
                {step < STEPS.length - 1 ? "Siguiente →" : "Enviar por WhatsApp"}
              </Button>
            </div>

            <div className="mt-6 space-y-2 border-t border-border pt-5 text-xs text-muted-foreground">
              <p className="flex items-center gap-2"><ShieldCheck className="size-4 text-primary" /> Tus datos están protegidos y no se comparten.</p>
              <p className="flex items-center gap-2"><Zap className="size-4 text-primary" /> Respuesta rápida por WhatsApp.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
