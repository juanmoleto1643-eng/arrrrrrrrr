import auctionYard from "@/assets/auction-yard.jpg";
import heroLot from "@/assets/hero-lot.jpg";
import carrier from "@/assets/carrier.jpg";

const ITEMS = [
  { n: "01", title: "Búsqueda del vehículo", text: "Revisamos subastas activas y te mostramos opciones reales con fotos, historial y un precio estimado acorde a tu presupuesto.", image: auctionYard },
  { n: "02", title: "Compra y documentos", text: "Te representamos en la subasta, hacemos la oferta y gestionamos pago y papeleo con total transparencia.", image: heroLot },
  { n: "03", title: "Transporte y entrega", text: "Organizamos el traslado desde la subasta hasta tu ciudad y te damos seguimiento hasta que recibes las llaves.", image: carrier },
];

export function Services() {
  return (
    <section id="servicios" className="mx-auto max-w-7xl px-4 py-24 sm:px-6">
      <div className="max-w-3xl">
        <p className="eyebrow">Nuestros servicios</p>
        <h2 className="mt-4 font-display text-5xl leading-none md:text-6xl">
          Contigo en cada paso, <span className="text-gradient-gold">de la búsqueda a tu puerta</span>
        </h2>
      </div>
      <div className="mt-14 grid gap-6 md:grid-cols-3">
        {ITEMS.map((s) => (
          <article key={s.n} className="group overflow-hidden rounded-2xl border border-border bg-card shadow-card">
            <div className="relative h-56 overflow-hidden">
              <img src={s.image} alt={s.title} loading="lazy" width={1600} height={1024} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-fade" />
              <span className="absolute bottom-4 left-5 font-display text-5xl text-gradient-gold">{s.n}</span>
            </div>
            <div className="p-6">
              <h3 className="font-display text-3xl tracking-wide">{s.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.text}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
