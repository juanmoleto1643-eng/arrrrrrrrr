import { useEffect, useState } from "react";
import { Menu, UserRound, X } from "lucide-react";
import { BRAND, NAV } from "@/lib/site-data";
import { Logo } from "./Logo";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="sticky top-0 z-50">
      <div className="border-b border-border bg-overlay px-4 py-2 text-center text-xs text-muted-foreground">
        {BRAND.hours}
      </div>
      <div
        className={cn(
          "border-b transition-colors",
          scrolled ? "border-border bg-background/90 backdrop-blur-md" : "border-transparent bg-background",
        )}
      >
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between gap-6 px-4 sm:px-6">
          <Logo />
          <nav className="hidden items-center gap-8 lg:flex" aria-label="Principal">
            {NAV.map((item, i) => (
              <a
                key={item.href}
                href={item.href}
                className={cn(
                  "relative text-sm font-medium transition-colors hover:text-primary",
                  i === 0 ? "text-primary" : "text-foreground/80",
                )}
              >
                {item.label}
                {i === 0 && <span className="absolute -bottom-2 left-1/2 size-1 -translate-x-1/2 rounded-full bg-primary" />}
              </a>
            ))}
          </nav>
          <div className="hidden items-center gap-5 lg:flex">
            <div className="flex items-center gap-2 text-xs font-semibold">
              <button className="text-muted-foreground transition-colors hover:text-foreground">EN</button>
              <span className="h-3 w-px bg-border" />
              <button className="text-foreground">ES</button>
            </div>
            <a href="#contacto" className="flex items-center gap-2 text-sm text-foreground/90 transition-colors hover:text-primary">
              <UserRound className="size-4 text-primary" /> Portal de Dealers
            </a>
          </div>
          <button
            className="grid size-10 place-items-center rounded-md border border-border text-foreground lg:hidden"
            onClick={() => setOpen((o) => !o)}
            aria-label={open ? "Cerrar menú" : "Abrir menú"}
            aria-expanded={open}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
        {open && (
          <nav className="border-t border-border bg-background px-4 py-4 lg:hidden" aria-label="Móvil">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="block rounded-md px-3 py-3 text-base font-medium text-foreground hover:bg-muted hover:text-primary"
              >
                {item.label}
              </a>
            ))}
            <a href="#contacto" onClick={() => setOpen(false)} className="mt-2 flex items-center gap-2 px-3 py-3 text-primary">
              <UserRound className="size-4" /> Portal de Dealers
            </a>
          </nav>
        )}
      </div>
    </header>
  );
}
